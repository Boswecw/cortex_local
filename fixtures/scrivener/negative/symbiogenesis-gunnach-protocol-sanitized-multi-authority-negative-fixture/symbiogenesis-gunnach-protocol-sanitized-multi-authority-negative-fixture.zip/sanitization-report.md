# Sanitization Report

Actions applied:
- replaced `content.rtf` and `notes.rtf` with placeholders
- replaced `synopsis.txt` with placeholder text
- sanitized binder/display titles in `*.scrivx`
- scrubbed selected device / modification metadata in `*.scrivx`
- removed bundled PDF exports if present
- removed autosave / backup binder artifacts if present

Purpose:
bounded derivative evidence only.
