# symbiogenesis-gunnach-protocol-sanitized-multi-authority-negative-fixture

Sanitized-derived negative Scrivener fixture.

This packet intentionally introduces a second conflicting top-level `*.scrivx` authority candidate in an otherwise package-shaped sanitized project copy.

Use:
- negative / irregular evidence only
- fail-closed authority ambiguity evidence
- not support proof
