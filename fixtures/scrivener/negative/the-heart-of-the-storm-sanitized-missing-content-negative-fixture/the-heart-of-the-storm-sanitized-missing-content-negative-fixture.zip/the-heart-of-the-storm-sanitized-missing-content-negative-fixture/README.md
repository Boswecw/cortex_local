# The Heart of the Storm — Sanitized Missing-Content Negative Fixture

Classification: negative, evidence only.

Derived from the sanitized fixture, then altered by removing one expected `content.rtf` artifact while leaving readable authority in place.
